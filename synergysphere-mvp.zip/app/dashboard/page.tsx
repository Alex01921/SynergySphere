import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { ProjectList } from "@/components/project-list"
import { CreateProjectDialog } from "@/components/create-project-dialog"
import { UserNav } from "@/components/user-nav"
import { DashboardStats } from "@/components/dashboard-stats"
import { RecentActivity } from "@/components/recent-activity"
import { QuickActions } from "@/components/quick-actions"

export default async function DashboardPage() {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  // Get user's projects with additional stats
  const { data: projects } = await supabase
    .from("projects")
    .select(`
      *,
      project_members!inner(role),
      tasks(id, status, due_date),
      discussions(id, updated_at)
    `)
    .order("created_at", { ascending: false })

  // Get user profile
  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  // Get recent tasks assigned to user
  const { data: recentTasks } = await supabase
    .from("tasks")
    .select(`
      *,
      projects(name),
      assignee:assignee_id(display_name)
    `)
    .eq("assignee_id", user.id)
    .order("updated_at", { ascending: false })
    .limit(5)

  // Get recent discussions user participated in
  const { data: recentDiscussions } = await supabase
    .from("discussions")
    .select(`
      *,
      projects(name),
      messages!inner(author_id)
    `)
    .eq("messages.author_id", user.id)
    .order("updated_at", { ascending: false })
    .limit(3)

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                <div className="w-4 h-4 bg-white rounded-sm"></div>
              </div>
              <h1 className="text-xl font-bold text-slate-900">SynergySphere</h1>
            </div>
            <UserNav user={user} profile={profile} />
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 sm:py-8">
        {/* Welcome Section */}
        <div className="mb-6 sm:mb-8">
          <h2 className="text-2xl sm:text-3xl font-bold text-slate-900 mb-2">
            Welcome back, {profile?.display_name || user.email?.split("@")[0]}
          </h2>
          <p className="text-slate-600">Here's what's happening with your projects today.</p>
        </div>

        {/* Dashboard Stats */}
        <DashboardStats projects={projects || []} userId={user.id} />

        {/* Mobile Quick Actions */}
        <div className="block lg:hidden mb-6">
          <QuickActions />
        </div>

        {/* Main Dashboard Grid */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 lg:gap-8">
          {/* Left Column - Projects */}
          <div className="lg:col-span-2 space-y-6">
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
              <div>
                <h3 className="text-xl font-semibold text-slate-900 mb-2">Your Projects</h3>
                <p className="text-slate-600 text-sm">Manage and collaborate on your team projects</p>
              </div>
              <div className="mt-4 sm:mt-0">
                <CreateProjectDialog />
              </div>
            </div>
            <ProjectList projects={projects || []} />
          </div>

          {/* Right Column - Activity & Quick Actions */}
          <div className="space-y-6">
            {/* Desktop Quick Actions */}
            <div className="hidden lg:block">
              <QuickActions />
            </div>

            {/* Recent Activity */}
            <RecentActivity recentTasks={recentTasks || []} recentDiscussions={recentDiscussions || []} />
          </div>
        </div>
      </main>
    </div>
  )
}
