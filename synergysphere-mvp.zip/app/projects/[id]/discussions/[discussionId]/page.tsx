import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { DiscussionView } from "@/components/discussion-view"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"

interface DiscussionPageProps {
  params: Promise<{ id: string; discussionId: string }>
}

export default async function DiscussionPage({ params }: DiscussionPageProps) {
  const { id: projectId, discussionId } = await params
  const supabase = await createClient()

  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  // Get discussion with project member check
  const { data: discussion } = await supabase
    .from("discussions")
    .select(`
      *,
      author:created_by(display_name, email, avatar_url),
      projects!inner(
        name,
        project_members!inner(user_id)
      )
    `)
    .eq("id", discussionId)
    .eq("project_id", projectId)
    .eq("projects.project_members.user_id", user.id)
    .single()

  if (!discussion) {
    redirect(`/projects/${projectId}`)
  }

  return (
    <div className="min-h-screen bg-slate-50">
      <header className="bg-white border-b border-slate-200">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center space-x-4">
            <Button variant="ghost" size="sm" asChild>
              <Link href={`/projects/${projectId}?tab=discussions`}>
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Discussions
              </Link>
            </Button>
            <div>
              <h1 className="text-xl font-semibold text-slate-900">{discussion.title}</h1>
              <p className="text-sm text-slate-600">in {discussion.projects.name}</p>
            </div>
          </div>
        </div>
      </header>

      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <DiscussionView discussionId={discussionId} discussion={discussion} />
      </main>
    </div>
  )
}
