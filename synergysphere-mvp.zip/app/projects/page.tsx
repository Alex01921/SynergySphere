import { redirect } from "next/navigation"
import { createClient } from "@/lib/supabase/server"
import { ProjectList } from "@/components/project-list"
import { CreateProjectDialog } from "@/components/create-project-dialog"
import { UserNav } from "@/components/user-nav"
import { Button } from "@/components/ui/button"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"

export default async function ProjectsPage() {
  const supabase = await createClient()
  const {
    data: { user },
  } = await supabase.auth.getUser()

  if (!user) {
    redirect("/auth/login")
  }

  // Get user's projects with additional stats
  const { data: projects } = await supabase
    .from("projects")
    .select(`
      *,
      project_members!inner(role),
      tasks(id, status, due_date),
      discussions(id, updated_at)
    `)
    .order("created_at", { ascending: false })

  // Get user profile
  const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

  return (
    <div className="min-h-screen bg-slate-50">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-3">
              <div className="w-8 h-8 bg-blue-600 rounded-lg flex items-center justify-center">
                <div className="w-4 h-4 bg-white rounded-sm"></div>
              </div>
              <h1 className="text-xl font-bold text-slate-900">SynergySphere</h1>
            </div>
            <UserNav user={user} profile={profile} />
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4 sm:py-8">
        {/* Back Navigation */}
        <div className="mb-6">
          <Button variant="ghost" size="sm" asChild>
            <Link href="/dashboard">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Dashboard
            </Link>
          </Button>
        </div>

        {/* Page Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-8">
          <div>
            <h2 className="text-3xl font-bold text-slate-900 mb-2">All Projects</h2>
            <p className="text-slate-600">Manage and collaborate on your team projects</p>
          </div>
          <div className="mt-4 sm:mt-0">
            <CreateProjectDialog />
          </div>
        </div>

        {/* Projects Grid */}
        <ProjectList projects={projects || []} />
      </main>
    </div>
  )
}
