import { Suspense } from "react"
import { InviteAcceptancePage } from "@/components/invite-acceptance-page"
import { Loader2 } from "lucide-react"

export default function InvitePage() {
  return (
    <Suspense
      fallback={
        <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 to-slate-100 p-4">
          <Loader2 className="w-8 h-8 text-blue-600 animate-spin" />
        </div>
      }
    >
      <InviteAcceptancePage />
    </Suspense>
  )
}
