"use client"

import { useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Calendar, MoreHorizontal, User } from "lucide-react"
import { format, isAfter, isToday, isTomorrow } from "date-fns"

interface Task {
  id: string
  title: string
  description: string | null
  status: "todo" | "in_progress" | "done"
  priority: "low" | "medium" | "high"
  due_date: string | null
  assignee_id: string | null
  created_by: string
  created_at: string
  updated_at: string
  assignee?: {
    display_name: string
    email: string
    avatar_url: string | null
  }
  creator?: {
    display_name: string
    email: string
    avatar_url: string | null
  }
}

interface Member {
  id: string
  role: string
  profiles: {
    display_name: string
    email: string
    avatar_url: string | null
  }
}

interface TaskCardProps {
  task: Task
  members: Member[]
  onUpdate: () => void
}

export function TaskCard({ task, members, onUpdate }: TaskCardProps) {
  const [isUpdating, setIsUpdating] = useState(false)

  const updateTaskStatus = async (newStatus: "todo" | "in_progress" | "done") => {
    setIsUpdating(true)
    const supabase = createClient()

    try {
      const { error } = await supabase.from("tasks").update({ status: newStatus }).eq("id", task.id)

      if (error) throw error
      onUpdate()
    } catch (error) {
      console.error("Error updating task:", error)
    } finally {
      setIsUpdating(false)
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "high":
        return "bg-red-100 text-red-800"
      case "medium":
        return "bg-yellow-100 text-yellow-800"
      case "low":
        return "bg-green-100 text-green-800"
      default:
        return "bg-slate-100 text-slate-800"
    }
  }

  const getDueDateDisplay = (dueDate: string | null) => {
    if (!dueDate) return null

    const date = new Date(dueDate)
    const now = new Date()

    if (isToday(date)) return { text: "Today", color: "text-orange-600" }
    if (isTomorrow(date)) return { text: "Tomorrow", color: "text-blue-600" }
    if (isAfter(now, date)) return { text: "Overdue", color: "text-red-600" }

    return { text: format(date, "MMM d"), color: "text-slate-600" }
  }

  const assigneeInitials =
    task.assignee?.display_name
      .split(" ")
      .map((n) => n[0])
      .join("")
      .toUpperCase()
      .slice(0, 2) || "?"

  const dueDateInfo = getDueDateDisplay(task.due_date)

  return (
    <Card className="bg-white hover:shadow-md transition-shadow duration-200 cursor-pointer">
      <CardHeader className="pb-2">
        <div className="flex items-start justify-between">
          <h3 className="font-medium text-slate-900 line-clamp-2 flex-1">{task.title}</h3>
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm" className="h-8 w-8 p-0">
                <MoreHorizontal className="h-4 w-4" />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              {task.status !== "todo" && (
                <DropdownMenuItem onClick={() => updateTaskStatus("todo")} disabled={isUpdating}>
                  Move to To Do
                </DropdownMenuItem>
              )}
              {task.status !== "in_progress" && (
                <DropdownMenuItem onClick={() => updateTaskStatus("in_progress")} disabled={isUpdating}>
                  Move to In Progress
                </DropdownMenuItem>
              )}
              {task.status !== "done" && (
                <DropdownMenuItem onClick={() => updateTaskStatus("done")} disabled={isUpdating}>
                  Move to Done
                </DropdownMenuItem>
              )}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        {task.description && <p className="text-sm text-slate-600 line-clamp-2 mt-1">{task.description}</p>}
      </CardHeader>

      <CardContent className="pt-0">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-2">
            <Badge variant="secondary" className={`text-xs ${getPriorityColor(task.priority)}`}>
              {task.priority}
            </Badge>

            {dueDateInfo && (
              <div className={`flex items-center text-xs ${dueDateInfo.color}`}>
                <Calendar className="w-3 h-3 mr-1" />
                {dueDateInfo.text}
              </div>
            )}
          </div>

          {task.assignee ? (
            <Avatar className="w-6 h-6">
              <AvatarImage src={task.assignee.avatar_url || ""} />
              <AvatarFallback className="bg-blue-600 text-white text-xs">{assigneeInitials}</AvatarFallback>
            </Avatar>
          ) : (
            <div className="w-6 h-6 rounded-full bg-slate-200 flex items-center justify-center">
              <User className="w-3 h-3 text-slate-500" />
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
