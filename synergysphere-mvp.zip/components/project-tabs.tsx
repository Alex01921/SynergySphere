"use client"

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { TaskBoard } from "@/components/task-board"
import { DiscussionBoard } from "@/components/discussion-board"
import { CheckSquare, MessageSquare } from "lucide-react"
import { useSearchParams } from "next/navigation"

interface Member {
  id: string
  role: string
  profiles: {
    display_name: string
    email: string
    avatar_url: string | null
  }
}

interface ProjectTabsProps {
  projectId: string
  members: Member[]
}

export function ProjectTabs({ projectId, members }: ProjectTabsProps) {
  const searchParams = useSearchParams()
  const defaultTab = searchParams.get("tab") || "tasks"

  return (
    <Tabs defaultValue={defaultTab} className="space-y-6">
      <TabsList className="grid w-full grid-cols-2 lg:w-[400px]">
        <TabsTrigger value="tasks" className="flex items-center space-x-2">
          <CheckSquare className="w-4 h-4" />
          <span>Tasks</span>
        </TabsTrigger>
        <TabsTrigger value="discussions" className="flex items-center space-x-2">
          <MessageSquare className="w-4 h-4" />
          <span>Discussions</span>
        </TabsTrigger>
      </TabsList>

      <TabsContent value="tasks" className="space-y-6">
        <TaskBoard projectId={projectId} members={members} />
      </TabsContent>

      <TabsContent value="discussions" className="space-y-6">
        <DiscussionBoard projectId={projectId} members={members} />
      </TabsContent>
    </Tabs>
  )
}
