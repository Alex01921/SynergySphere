"use client"

import { useState, useEffect } from "react"
import { createClient } from "@/lib/supabase/client"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Plus, MessageSquare } from "lucide-react"
import { CreateDiscussionDialog } from "@/components/create-discussion-dialog"
import { DiscussionCard } from "@/components/discussion-card"

interface Member {
  id: string
  role: string
  profiles: {
    display_name: string
    email: string
    avatar_url: string | null
  }
}

interface Discussion {
  id: string
  title: string
  created_at: string
  updated_at: string
  created_by: string
  author: {
    display_name: string
    email: string
    avatar_url: string | null
  }
  _count: {
    messages: number
  }
  latest_message?: {
    content: string
    created_at: string
    author: {
      display_name: string
    }
  }
}

interface DiscussionBoardProps {
  projectId: string
  members: Member[]
}

export function DiscussionBoard({ projectId, members }: DiscussionBoardProps) {
  const [discussions, setDiscussions] = useState<Discussion[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [createDialogOpen, setCreateDialogOpen] = useState(false)

  const fetchDiscussions = async () => {
    const supabase = createClient()
    const { data, error } = await supabase
      .from("discussions")
      .select(`
        *,
        author:created_by(display_name, email, avatar_url),
        messages(count),
        latest_message:messages(
          content,
          created_at,
          author:author_id(display_name)
        )
      `)
      .eq("project_id", projectId)
      .order("updated_at", { ascending: false })

    if (error) {
      console.error("Error fetching discussions:", error)
    } else {
      // Process the data to get message counts and latest messages
      const processedData =
        data?.map((discussion) => ({
          ...discussion,
          _count: {
            messages: discussion.messages?.length || 0,
          },
          latest_message: discussion.latest_message?.[0] || null,
        })) || []

      setDiscussions(processedData)
    }
    setIsLoading(false)
  }

  useEffect(() => {
    fetchDiscussions()
  }, [projectId])

  const handleDiscussionCreated = () => {
    fetchDiscussions()
    setCreateDialogOpen(false)
  }

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-semibold text-slate-900">Discussions</h2>
          <Button disabled>
            <Plus className="w-4 h-4 mr-2" />
            New Discussion
          </Button>
        </div>
        <div className="space-y-4">
          {[1, 2, 3].map((i) => (
            <Card key={i} className="animate-pulse">
              <CardHeader>
                <div className="h-4 bg-slate-200 rounded w-3/4"></div>
                <div className="h-3 bg-slate-200 rounded w-1/2"></div>
              </CardHeader>
              <CardContent>
                <div className="h-3 bg-slate-200 rounded w-full"></div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-semibold text-slate-900">Discussions</h2>
        <Button className="bg-blue-600 hover:bg-blue-700" onClick={() => setCreateDialogOpen(true)}>
          <Plus className="w-4 h-4 mr-2" />
          New Discussion
        </Button>
      </div>

      {discussions.length === 0 ? (
        <Card className="text-center py-12">
          <CardContent>
            <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <MessageSquare className="w-8 h-8 text-slate-400" />
            </div>
            <h3 className="text-lg font-medium text-slate-900 mb-2">No discussions yet</h3>
            <p className="text-slate-600 mb-6">Start a conversation with your team members</p>
            <Button onClick={() => setCreateDialogOpen(true)}>
              <Plus className="w-4 h-4 mr-2" />
              Start Discussion
            </Button>
          </CardContent>
        </Card>
      ) : (
        <div className="space-y-4">
          {discussions.map((discussion) => (
            <DiscussionCard key={discussion.id} discussion={discussion} projectId={projectId} />
          ))}
        </div>
      )}

      <CreateDiscussionDialog
        open={createDialogOpen}
        onOpenChange={setCreateDialogOpen}
        projectId={projectId}
        onDiscussionCreated={handleDiscussionCreated}
      />
    </div>
  )
}
