"use client"

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import Link from "next/link"
import { formatDistanceToNow } from "date-fns"

interface Project {
  id: string
  name: string
  description: string | null
  created_at: string
  project_members: { role: string }[]
  _count: { count: number }[]
}

interface ProjectListProps {
  projects: Project[]
}

export function ProjectList({ projects }: ProjectListProps) {
  if (projects.length === 0) {
    return (
      <div className="text-center py-12">
        <div className="w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <svg className="w-8 h-8 text-slate-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path
              strokeLinecap="round"
              strokeLinejoin="round"
              strokeWidth={2}
              d="M19 11H5m14 0a2 2 0 012 2v6a2 2 0 01-2 2H5a2 2 0 01-2-2v-6a2 2 0 012-2m14 0V9a2 2 0 00-2-2M5 9a2 2 0 012-2m0 0V5a2 2 0 012 2v2M7 7h10"
            />
          </svg>
        </div>
        <h3 className="text-lg font-medium text-slate-900 mb-2">No projects yet</h3>
        <p className="text-slate-600 mb-6">Create your first project to start collaborating with your team</p>
      </div>
    )
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-6">
      {projects.map((project) => {
        const memberCount = project._count?.[0]?.count || 0
        const userRole = project.project_members[0]?.role || "member"

        return (
          <Card key={project.id} className="hover:shadow-lg transition-shadow duration-200">
            <CardHeader className="pb-3">
              <div className="flex items-start justify-between">
                <div className="flex-1">
                  <CardTitle className="text-lg font-semibold text-slate-900 line-clamp-1">{project.name}</CardTitle>
                  <CardDescription className="mt-1 line-clamp-2">
                    {project.description || "No description provided"}
                  </CardDescription>
                </div>
                <Badge variant={userRole === "owner" ? "default" : "secondary"} className="ml-2">
                  {userRole}
                </Badge>
              </div>
            </CardHeader>
            <CardContent className="pt-0">
              <div className="flex items-center justify-between text-sm text-slate-600 mb-4">
                <span>
                  {memberCount} member{memberCount !== 1 ? "s" : ""}
                </span>
                <span>Created {formatDistanceToNow(new Date(project.created_at), { addSuffix: true })}</span>
              </div>
              <Button asChild className="w-full">
                <Link href={`/projects/${project.id}`}>View Project</Link>
              </Button>
            </CardContent>
          </Card>
        )
      })}
    </div>
  )
}
