"use client"

import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { MessageSquare, Clock } from "lucide-react"
import { formatDistanceToNow } from "date-fns"
import Link from "next/link"

interface Discussion {
  id: string
  title: string
  created_at: string
  updated_at: string
  created_by: string
  author: {
    display_name: string
    email: string
    avatar_url: string | null
  }
  _count: {
    messages: number
  }
  latest_message?: {
    content: string
    created_at: string
    author: {
      display_name: string
    }
  }
}

interface DiscussionCardProps {
  discussion: Discussion
  projectId: string
}

export function DiscussionCard({ discussion, projectId }: DiscussionCardProps) {
  const authorInitials = discussion.author.display_name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .toUpperCase()
    .slice(0, 2)

  return (
    <Link href={`/projects/${projectId}/discussions/${discussion.id}`}>
      <Card className="hover:shadow-md transition-shadow duration-200 cursor-pointer">
        <CardHeader className="pb-3">
          <div className="flex items-start justify-between">
            <div className="flex-1">
              <h3 className="font-semibold text-slate-900 line-clamp-1 mb-2">{discussion.title}</h3>
              <div className="flex items-center space-x-3 text-sm text-slate-600">
                <div className="flex items-center space-x-2">
                  <Avatar className="w-5 h-5">
                    <AvatarImage src={discussion.author.avatar_url || ""} />
                    <AvatarFallback className="bg-blue-600 text-white text-xs">{authorInitials}</AvatarFallback>
                  </Avatar>
                  <span>{discussion.author.display_name}</span>
                </div>
                <div className="flex items-center space-x-1">
                  <Clock className="w-3 h-3" />
                  <span>{formatDistanceToNow(new Date(discussion.created_at), { addSuffix: true })}</span>
                </div>
              </div>
            </div>
            <Badge variant="secondary" className="flex items-center space-x-1">
              <MessageSquare className="w-3 h-3" />
              <span>{discussion._count.messages}</span>
            </Badge>
          </div>
        </CardHeader>

        {discussion.latest_message && (
          <CardContent className="pt-0">
            <div className="bg-slate-50 rounded-lg p-3">
              <p className="text-sm text-slate-700 line-clamp-2">{discussion.latest_message.content}</p>
              <div className="flex items-center justify-between mt-2 text-xs text-slate-500">
                <span>Latest by {discussion.latest_message.author.display_name}</span>
                <span>{formatDistanceToNow(new Date(discussion.latest_message.created_at), { addSuffix: true })}</span>
              </div>
            </div>
          </CardContent>
        )}
      </Card>
    </Link>
  )
}
