"use client"

import { useState, useEffect } from "react"
import { createClient } from "@/lib/supabase/client"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Plus } from "lucide-react"
import { CreateTaskDialog } from "@/components/create-task-dialog"
import { TaskCard } from "@/components/task-card"

interface Member {
  id: string
  role: string
  profiles: {
    display_name: string
    email: string
    avatar_url: string | null
  }
}

interface Task {
  id: string
  title: string
  description: string | null
  status: "todo" | "in_progress" | "done"
  priority: "low" | "medium" | "high"
  due_date: string | null
  assignee_id: string | null
  created_by: string
  created_at: string
  updated_at: string
  assignee?: {
    display_name: string
    email: string
    avatar_url: string | null
  }
  creator?: {
    display_name: string
    email: string
    avatar_url: string | null
  }
}

interface TaskBoardProps {
  projectId: string
  members: Member[]
}

export function TaskBoard({ projectId, members }: TaskBoardProps) {
  const [tasks, setTasks] = useState<Task[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [createDialogOpen, setCreateDialogOpen] = useState(false)

  const fetchTasks = async () => {
    const supabase = createClient()
    const { data, error } = await supabase
      .from("tasks")
      .select(`
        *,
        assignee:assignee_id(display_name, email, avatar_url),
        creator:created_by(display_name, email, avatar_url)
      `)
      .eq("project_id", projectId)
      .order("created_at", { ascending: false })

    if (error) {
      console.error("Error fetching tasks:", error)
    } else {
      setTasks(data || [])
    }
    setIsLoading(false)
  }

  useEffect(() => {
    fetchTasks()
  }, [projectId])

  const handleTaskCreated = () => {
    fetchTasks()
    setCreateDialogOpen(false)
  }

  const handleTaskUpdated = () => {
    fetchTasks()
  }

  const columns = [
    {
      id: "todo",
      title: "To Do",
      tasks: tasks.filter((task) => task.status === "todo"),
      color: "bg-slate-50",
    },
    {
      id: "in_progress",
      title: "In Progress",
      tasks: tasks.filter((task) => task.status === "in_progress"),
      color: "bg-blue-50",
    },
    {
      id: "done",
      title: "Done",
      tasks: tasks.filter((task) => task.status === "done"),
      color: "bg-green-50",
    },
  ]

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <h2 className="text-xl font-semibold text-slate-900">Tasks</h2>
          <Button disabled>
            <Plus className="w-4 h-4 mr-2" />
            Add Task
          </Button>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {[1, 2, 3].map((i) => (
            <Card key={i} className="bg-slate-50 animate-pulse">
              <CardHeader className="pb-3">
                <div className="h-4 bg-slate-200 rounded w-20"></div>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  <div className="h-20 bg-slate-200 rounded"></div>
                  <div className="h-20 bg-slate-200 rounded"></div>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-semibold text-slate-900">Tasks</h2>
        <Button className="bg-blue-600 hover:bg-blue-700" onClick={() => setCreateDialogOpen(true)}>
          <Plus className="w-4 h-4 mr-2" />
          Add Task
        </Button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {columns.map((column) => (
          <Card key={column.id} className={column.color}>
            <CardHeader className="pb-3">
              <CardTitle className="text-sm font-medium text-slate-700 uppercase tracking-wide">
                {column.title}
                <span className="ml-2 text-xs bg-white text-slate-600 px-2 py-1 rounded-full">
                  {column.tasks.length}
                </span>
              </CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {column.tasks.length === 0 ? (
                <div className="text-center py-8 text-slate-500">
                  <div className="w-12 h-12 bg-slate-200 rounded-full flex items-center justify-center mx-auto mb-3">
                    <Plus className="w-6 h-6" />
                  </div>
                  <p className="text-sm">No tasks yet</p>
                </div>
              ) : (
                column.tasks.map((task) => (
                  <TaskCard key={task.id} task={task} members={members} onUpdate={handleTaskUpdated} />
                ))
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      <CreateTaskDialog
        open={createDialogOpen}
        onOpenChange={setCreateDialogOpen}
        projectId={projectId}
        members={members}
        onTaskCreated={handleTaskCreated}
      />
    </div>
  )
}
