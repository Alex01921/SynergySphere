"use client"

import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { ArrowLeft, Settings, Users } from "lucide-react"
import Link from "next/link"
import { formatDistanceToNow } from "date-fns"
import { TeamMembersDialog } from "@/components/team-members-dialog"
import { useState } from "react"

interface Project {
  id: string
  name: string
  description: string | null
  created_at: string
  project_members: {
    role: string
    profiles: {
      display_name: string
      email: string
      avatar_url: string | null
    }
  }[]
}

interface Member {
  id: string
  role: string
  profiles: {
    display_name: string
    email: string
    avatar_url: string | null
  }
}

interface ProjectHeaderProps {
  project: Project
  members: Member[]
}

export function ProjectHeader({ project, members }: ProjectHeaderProps) {
  const userRole = project.project_members[0]?.role || "member"
  const [teamDialogOpen, setTeamDialogOpen] = useState(false)

  return (
    <header className="bg-white border-b border-slate-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="py-6">
          <div className="flex items-center justify-between mb-4">
            <Button variant="ghost" size="sm" asChild>
              <Link href="/dashboard">
                <ArrowLeft className="w-4 h-4 mr-2" />
                Back to Dashboard
              </Link>
            </Button>
            <div className="flex items-center space-x-2">
              <Button variant="outline" size="sm" onClick={() => setTeamDialogOpen(true)}>
                <Users className="w-4 h-4 mr-2" />
                {members.length} Member{members.length !== 1 ? "s" : ""}
              </Button>
              {(userRole === "owner" || userRole === "admin") && (
                <Button variant="outline" size="sm">
                  <Settings className="w-4 h-4 mr-2" />
                  Settings
                </Button>
              )}
            </div>
          </div>

          <div className="flex flex-col sm:flex-row sm:items-start sm:justify-between">
            <div className="flex-1">
              <div className="flex items-center space-x-3 mb-2">
                <h1 className="text-2xl font-bold text-slate-900">{project.name}</h1>
                <Badge variant={userRole === "owner" ? "default" : "secondary"}>{userRole}</Badge>
              </div>
              {project.description && <p className="text-slate-600 mb-4">{project.description}</p>}
              <p className="text-sm text-slate-500">
                Created {formatDistanceToNow(new Date(project.created_at), { addSuffix: true })}
              </p>
            </div>

            <div className="flex items-center space-x-2 mt-4 sm:mt-0">
              <div className="flex -space-x-2">
                {members.slice(0, 5).map((member) => {
                  const initials = member.profiles.display_name
                    .split(" ")
                    .map((n) => n[0])
                    .join("")
                    .toUpperCase()
                    .slice(0, 2)

                  return (
                    <Avatar key={member.id} className="w-8 h-8 border-2 border-white">
                      <AvatarImage src={member.profiles.avatar_url || ""} />
                      <AvatarFallback className="bg-blue-600 text-white text-xs">{initials}</AvatarFallback>
                    </Avatar>
                  )
                })}
                {members.length > 5 && (
                  <div className="w-8 h-8 rounded-full bg-slate-100 border-2 border-white flex items-center justify-center">
                    <span className="text-xs text-slate-600">+{members.length - 5}</span>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      </div>
      <TeamMembersDialog
        open={teamDialogOpen}
        onOpenChange={setTeamDialogOpen}
        project={project}
        members={members}
        userRole={userRole}
      />
    </header>
  )
}
