"use client"

import type React from "react"

import { useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { Button } from "@/components/ui/button"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"

interface CreateDiscussionDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  projectId: string
  onDiscussionCreated: () => void
}

export function CreateDiscussionDialog({
  open,
  onOpenChange,
  projectId,
  onDiscussionCreated,
}: CreateDiscussionDialogProps) {
  const [title, setTitle] = useState("")
  const [initialMessage, setInitialMessage] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState<string | null>(null)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!title.trim()) return

    setIsLoading(true)
    setError(null)
    const supabase = createClient()

    try {
      const {
        data: { user },
      } = await supabase.auth.getUser()
      if (!user) throw new Error("Not authenticated")

      // Create discussion
      const { data: discussion, error: discussionError } = await supabase
        .from("discussions")
        .insert({
          title: title.trim(),
          project_id: projectId,
          created_by: user.id,
        })
        .select()
        .single()

      if (discussionError) throw discussionError

      // Create initial message if provided
      if (initialMessage.trim()) {
        const { error: messageError } = await supabase.from("messages").insert({
          discussion_id: discussion.id,
          content: initialMessage.trim(),
          author_id: user.id,
        })

        if (messageError) throw messageError
      }

      // Reset form
      setTitle("")
      setInitialMessage("")

      onDiscussionCreated()
    } catch (error: unknown) {
      setError(error instanceof Error ? error.message : "Failed to create discussion")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[500px]">
        <form onSubmit={handleSubmit}>
          <DialogHeader>
            <DialogTitle>Start New Discussion</DialogTitle>
            <DialogDescription>Create a new discussion topic for your team to collaborate on.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="space-y-2">
              <Label htmlFor="title">Discussion Title</Label>
              <Input
                id="title"
                placeholder="Enter discussion title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="message">Initial Message (Optional)</Label>
              <Textarea
                id="message"
                placeholder="Start the conversation..."
                value={initialMessage}
                onChange={(e) => setInitialMessage(e.target.value)}
                rows={4}
              />
            </div>

            {error && <div className="text-sm text-red-600 bg-red-50 p-3 rounded-lg">{error}</div>}
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={() => onOpenChange(false)}>
              Cancel
            </Button>
            <Button type="submit" disabled={isLoading || !title.trim()}>
              {isLoading ? "Creating..." : "Create Discussion"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}
