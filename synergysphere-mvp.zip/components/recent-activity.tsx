"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { CheckSquare, MessageSquare, Clock } from "lucide-react"
import { formatDistanceToNow } from "date-fns"

interface Task {
  id: string
  title: string
  status: string
  due_date: string | null
  updated_at: string
  projects: { name: string }
  assignee: { display_name: string } | null
}

interface Discussion {
  id: string
  title: string
  updated_at: string
  projects: { name: string }
}

interface RecentActivityProps {
  recentTasks: Task[]
  recentDiscussions: Discussion[]
}

export function RecentActivity({ recentTasks, recentDiscussions }: RecentActivityProps) {
  const getStatusColor = (status: string) => {
    switch (status) {
      case "done":
        return "bg-green-100 text-green-800"
      case "in_progress":
        return "bg-blue-100 text-blue-800"
      default:
        return "bg-slate-100 text-slate-800"
    }
  }

  return (
    <div className="space-y-6">
      {/* Recent Tasks */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg flex items-center space-x-2">
            <CheckSquare className="w-5 h-5" />
            <span>Your Recent Tasks</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {recentTasks.length === 0 ? (
            <p className="text-sm text-slate-500 text-center py-4">No recent tasks</p>
          ) : (
            recentTasks.slice(0, 5).map((task) => (
              <div key={task.id} className="flex items-start space-x-3 p-2 rounded-lg hover:bg-slate-50">
                <div className="w-2 h-2 bg-blue-600 rounded-full mt-2 flex-shrink-0"></div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-slate-900 line-clamp-1">{task.title}</p>
                  <div className="flex items-center space-x-2 mt-1">
                    <Badge variant="secondary" className={`text-xs ${getStatusColor(task.status)}`}>
                      {task.status.replace("_", " ")}
                    </Badge>
                    <span className="text-xs text-slate-500">{task.projects.name}</span>
                  </div>
                  <div className="flex items-center space-x-1 mt-1">
                    <Clock className="w-3 h-3 text-slate-400" />
                    <span className="text-xs text-slate-500">
                      {formatDistanceToNow(new Date(task.updated_at), { addSuffix: true })}
                    </span>
                  </div>
                </div>
              </div>
            ))
          )}
        </CardContent>
      </Card>

      {/* Recent Discussions */}
      <Card>
        <CardHeader className="pb-3">
          <CardTitle className="text-lg flex items-center space-x-2">
            <MessageSquare className="w-5 h-5" />
            <span>Recent Discussions</span>
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {recentDiscussions.length === 0 ? (
            <p className="text-sm text-slate-500 text-center py-4">No recent discussions</p>
          ) : (
            recentDiscussions.slice(0, 3).map((discussion) => (
              <div key={discussion.id} className="flex items-start space-x-3 p-2 rounded-lg hover:bg-slate-50">
                <div className="w-2 h-2 bg-purple-600 rounded-full mt-2 flex-shrink-0"></div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-slate-900 line-clamp-1">{discussion.title}</p>
                  <p className="text-xs text-slate-500 mt-1">{discussion.projects.name}</p>
                  <div className="flex items-center space-x-1 mt-1">
                    <Clock className="w-3 h-3 text-slate-400" />
                    <span className="text-xs text-slate-500">
                      {formatDistanceToNow(new Date(discussion.updated_at), { addSuffix: true })}
                    </span>
                  </div>
                </div>
              </div>
            ))
          )}
        </CardContent>
      </Card>
    </div>
  )
}
