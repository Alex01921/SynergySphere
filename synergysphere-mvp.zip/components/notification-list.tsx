"use client"

import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import { CheckSquare, MessageSquare, Users, FolderOpen, Clock, CheckCheck, Bell } from "lucide-react"
import { formatDistanceToNow } from "date-fns"
import { useRouter } from "next/navigation"

interface Notification {
  id: string
  type: string
  title: string
  message: string
  data: any
  read_at: string | null
  created_at: string
}

interface NotificationListProps {
  notifications: Notification[]
  onMarkAsRead: (id: string) => void
  onMarkAllAsRead: () => void
  onClose: () => void
}

export function NotificationList({ notifications, onMarkAsRead, onMarkAllAsRead, onClose }: NotificationListProps) {
  const router = useRouter()

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case "task_assigned":
      case "task_due":
        return CheckSquare
      case "new_message":
        return MessageSquare
      case "project_invitation":
      case "project_update":
        return FolderOpen
      case "member_added":
        return Users
      default:
        return Clock
    }
  }

  const getNotificationColor = (type: string) => {
    switch (type) {
      case "task_assigned":
        return "text-blue-600"
      case "task_due":
        return "text-orange-600"
      case "new_message":
        return "text-purple-600"
      case "project_invitation":
      case "project_update":
        return "text-green-600"
      case "member_added":
        return "text-indigo-600"
      default:
        return "text-slate-600"
    }
  }

  const handleNotificationClick = (notification: Notification) => {
    // Mark as read
    if (!notification.read_at) {
      onMarkAsRead(notification.id)
    }

    // Navigate based on notification type
    const data = notification.data
    switch (notification.type) {
      case "task_assigned":
        if (data.project_id) {
          router.push(`/projects/${data.project_id}`)
        }
        break
      case "new_message":
        if (data.discussion_id && data.project_id) {
          router.push(`/projects/${data.project_id}/discussions/${data.discussion_id}`)
        }
        break
      case "project_invitation":
      case "project_update":
      case "member_added":
        if (data.project_id) {
          router.push(`/projects/${data.project_id}`)
        }
        break
    }

    onClose()
  }

  const unreadCount = notifications.filter((n) => !n.read_at).length

  return (
    <div className="p-2">
      {/* Header */}
      <div className="flex items-center justify-between p-2">
        <h3 className="font-semibold text-slate-900">Notifications</h3>
        {unreadCount > 0 && (
          <Button variant="ghost" size="sm" onClick={onMarkAllAsRead} className="text-xs">
            <CheckCheck className="w-3 h-3 mr-1" />
            Mark all read
          </Button>
        )}
      </div>

      <Separator className="my-2" />

      {/* Notifications List */}
      <div className="space-y-1">
        {notifications.length === 0 ? (
          <div className="text-center py-8">
            <Bell className="w-8 h-8 text-slate-300 mx-auto mb-2" />
            <p className="text-sm text-slate-500">No notifications yet</p>
          </div>
        ) : (
          notifications.map((notification) => {
            const Icon = getNotificationIcon(notification.type)
            const iconColor = getNotificationColor(notification.type)
            const isUnread = !notification.read_at

            return (
              <div
                key={notification.id}
                className={`p-3 rounded-lg cursor-pointer transition-colors hover:bg-slate-50 ${
                  isUnread ? "bg-blue-50 border-l-2 border-blue-500" : ""
                }`}
                onClick={() => handleNotificationClick(notification)}
              >
                <div className="flex items-start space-x-3">
                  <div className={`mt-0.5 ${iconColor}`}>
                    <Icon className="w-4 h-4" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <p className={`text-sm font-medium ${isUnread ? "text-slate-900" : "text-slate-700"}`}>
                        {notification.title}
                      </p>
                      {isUnread && <div className="w-2 h-2 bg-blue-600 rounded-full flex-shrink-0"></div>}
                    </div>
                    <p className="text-xs text-slate-600 mt-1 line-clamp-2">{notification.message}</p>
                    <p className="text-xs text-slate-500 mt-1">
                      {formatDistanceToNow(new Date(notification.created_at), { addSuffix: true })}
                    </p>
                  </div>
                </div>
              </div>
            )
          })
        )}
      </div>

      {notifications.length > 0 && (
        <>
          <Separator className="my-2" />
          <div className="p-2">
            <Button variant="ghost" size="sm" className="w-full text-xs" onClick={onClose}>
              View all notifications
            </Button>
          </div>
        </>
      )}
    </div>
  )
}
