"use client"

import { useState, useEffect } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { createClient } from "@/lib/supabase/client"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { CheckCircle, XCircle, Loader2 } from "lucide-react"

export function InviteAcceptancePage() {
  const [status, setStatus] = useState<"loading" | "success" | "error" | "expired">("loading")
  const [projectName, setProjectName] = useState("")
  const [error, setError] = useState("")
  const router = useRouter()
  const searchParams = useSearchParams()
  const token = searchParams.get("token")

  useEffect(() => {
    if (!token) {
      setStatus("error")
      setError("Invalid invitation link")
      return
    }

    acceptInvitation()
  }, [token])

  const acceptInvitation = async () => {
    const supabase = createClient()

    try {
      const {
        data: { user },
      } = await supabase.auth.getUser()

      if (!user) {
        // Redirect to login with return URL
        router.push(`/auth/login?redirect=${encodeURIComponent(window.location.href)}`)
        return
      }

      // Get invitation details
      const { data: invitation, error: inviteError } = await supabase
        .from("project_invitations")
        .select(`
          *,
          projects(name)
        `)
        .eq("token", token)
        .eq("email", user.email)
        .is("accepted_at", null)
        .single()

      if (inviteError || !invitation) {
        setStatus("error")
        setError("Invitation not found or already accepted")
        return
      }

      // Check if invitation is expired
      if (new Date(invitation.expires_at) < new Date()) {
        setStatus("expired")
        return
      }

      setProjectName(invitation.projects.name)

      // Check if user is already a member
      const { data: existingMember } = await supabase
        .from("project_members")
        .select("id")
        .eq("project_id", invitation.project_id)
        .eq("user_id", user.id)
        .single()

      if (existingMember) {
        // Mark invitation as accepted and redirect
        await supabase
          .from("project_invitations")
          .update({ accepted_at: new Date().toISOString() })
          .eq("id", invitation.id)

        setStatus("success")
        setTimeout(() => router.push(`/projects/${invitation.project_id}`), 2000)
        return
      }

      // Add user to project
      const { error: memberError } = await supabase.from("project_members").insert({
        project_id: invitation.project_id,
        user_id: user.id,
        role: invitation.role,
      })

      if (memberError) throw memberError

      // Mark invitation as accepted
      await supabase
        .from("project_invitations")
        .update({ accepted_at: new Date().toISOString() })
        .eq("id", invitation.id)

      setStatus("success")
      setTimeout(() => router.push(`/projects/${invitation.project_id}`), 2000)
    } catch (error: unknown) {
      setStatus("error")
      setError(error instanceof Error ? error.message : "Failed to accept invitation")
    }
  }

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-50 to-slate-100 p-4">
      <div className="w-full max-w-md">
        <Card className="shadow-xl border-0">
          <CardHeader className="text-center">
            {status === "loading" && (
              <>
                <Loader2 className="w-12 h-12 text-blue-600 animate-spin mx-auto mb-4" />
                <CardTitle>Processing Invitation</CardTitle>
                <CardDescription>Please wait while we process your invitation...</CardDescription>
              </>
            )}

            {status === "success" && (
              <>
                <CheckCircle className="w-12 h-12 text-green-600 mx-auto mb-4" />
                <CardTitle className="text-green-900">Welcome to {projectName}!</CardTitle>
                <CardDescription>You've successfully joined the project. Redirecting...</CardDescription>
              </>
            )}

            {status === "expired" && (
              <>
                <XCircle className="w-12 h-12 text-orange-600 mx-auto mb-4" />
                <CardTitle className="text-orange-900">Invitation Expired</CardTitle>
                <CardDescription>This invitation has expired. Please request a new one.</CardDescription>
              </>
            )}

            {status === "error" && (
              <>
                <XCircle className="w-12 h-12 text-red-600 mx-auto mb-4" />
                <CardTitle className="text-red-900">Error</CardTitle>
                <CardDescription>{error}</CardDescription>
              </>
            )}
          </CardHeader>

          {(status === "error" || status === "expired") && (
            <CardContent>
              <Button onClick={() => router.push("/dashboard")} className="w-full">
                Go to Dashboard
              </Button>
            </CardContent>
          )}
        </Card>
      </div>
    </div>
  )
}
