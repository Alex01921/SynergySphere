"use client"

import type React from "react"

import { useState } from "react"
import { createClient } from "@/lib/supabase/client"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Separator } from "@/components/ui/separator"
import { Trash2, UserPlus, Mail, Users } from "lucide-react"
import { useRouter } from "next/navigation"

interface Project {
  id: string
  name: string
  description: string | null
  created_at: string
  project_members: {
    role: string
    profiles: {
      display_name: string
      email: string
      avatar_url: string | null
    }
  }[]
}

interface Member {
  id: string
  role: string
  profiles: {
    display_name: string
    email: string
    avatar_url: string | null
  }
}

interface TeamMembersDialogProps {
  open: boolean
  onOpenChange: (open: boolean) => void
  project: Project
  members: Member[]
  userRole: string
}

export function TeamMembersDialog({ open, onOpenChange, project, members, userRole }: TeamMembersDialogProps) {
  const [inviteEmail, setInviteEmail] = useState("")
  const [inviteRole, setInviteRole] = useState<"member" | "admin">("member")
  const [isInviting, setIsInviting] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<string | null>(null)
  const router = useRouter()

  const canManageMembers = userRole === "owner" || userRole === "admin"

  const handleInviteMember = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!inviteEmail.trim() || !canManageMembers) return

    setIsInviting(true)
    setError(null)
    setSuccess(null)
    const supabase = createClient()

    try {
      // Check if user exists in profiles
      const { data: existingProfile } = await supabase
        .from("profiles")
        .select("id")
        .eq("email", inviteEmail.trim())
        .single()

      if (!existingProfile) {
        setError("User not found. They need to create an account first.")
        return
      }

      // Check if user is already a member
      const { data: existingMember } = await supabase
        .from("project_members")
        .select("id")
        .eq("project_id", project.id)
        .eq("user_id", existingProfile.id)
        .single()

      if (existingMember) {
        setError("User is already a member of this project.")
        return
      }

      // Add user to project
      const { error: memberError } = await supabase.from("project_members").insert({
        project_id: project.id,
        user_id: existingProfile.id,
        role: inviteRole,
      })

      if (memberError) throw memberError

      setSuccess("Member invited successfully!")
      setInviteEmail("")
      setInviteRole("member")
      router.refresh()
    } catch (error: unknown) {
      setError(error instanceof Error ? error.message : "Failed to invite member")
    } finally {
      setIsInviting(false)
    }
  }

  const handleRoleChange = async (memberId: string, newRole: string) => {
    if (!canManageMembers) return

    const supabase = createClient()
    try {
      const { error } = await supabase.from("project_members").update({ role: newRole }).eq("id", memberId)

      if (error) throw error
      router.refresh()
    } catch (error) {
      console.error("Error updating role:", error)
    }
  }

  const handleRemoveMember = async (memberId: string) => {
    if (!canManageMembers) return

    const supabase = createClient()
    try {
      const { error } = await supabase.from("project_members").delete().eq("id", memberId)

      if (error) throw error
      router.refresh()
    } catch (error) {
      console.error("Error removing member:", error)
    }
  }

  const getRoleBadgeColor = (role: string) => {
    switch (role) {
      case "owner":
        return "bg-purple-100 text-purple-800"
      case "admin":
        return "bg-blue-100 text-blue-800"
      default:
        return "bg-slate-100 text-slate-800"
    }
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[600px] max-h-[80vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="flex items-center space-x-2">
            <Users className="w-5 h-5" />
            <span>Team Members</span>
          </DialogTitle>
          <DialogDescription>Manage your project team members and their roles.</DialogDescription>
        </DialogHeader>

        <div className="space-y-6">
          {/* Invite New Member */}
          {canManageMembers && (
            <div className="space-y-4">
              <div className="flex items-center space-x-2">
                <UserPlus className="w-4 h-4 text-blue-600" />
                <h3 className="font-medium text-slate-900">Invite New Member</h3>
              </div>

              <form onSubmit={handleInviteMember} className="space-y-3">
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <div className="sm:col-span-2">
                    <Label htmlFor="email" className="sr-only">
                      Email
                    </Label>
                    <Input
                      id="email"
                      type="email"
                      placeholder="Enter email address"
                      value={inviteEmail}
                      onChange={(e) => setInviteEmail(e.target.value)}
                      required
                    />
                  </div>
                  <Select value={inviteRole} onValueChange={(value: "member" | "admin") => setInviteRole(value)}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="member">Member</SelectItem>
                      <SelectItem value="admin">Admin</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <Button type="submit" disabled={isInviting || !inviteEmail.trim()} className="w-full sm:w-auto">
                  <Mail className="w-4 h-4 mr-2" />
                  {isInviting ? "Inviting..." : "Invite Member"}
                </Button>
              </form>

              {error && <div className="text-sm text-red-600 bg-red-50 p-3 rounded-lg">{error}</div>}
              {success && <div className="text-sm text-green-600 bg-green-50 p-3 rounded-lg">{success}</div>}

              <Separator />
            </div>
          )}

          {/* Current Members */}
          <div className="space-y-4">
            <h3 className="font-medium text-slate-900">Current Members ({members.length})</h3>

            <div className="space-y-3">
              {members.map((member) => {
                const initials = member.profiles.display_name
                  .split(" ")
                  .map((n) => n[0])
                  .join("")
                  .toUpperCase()
                  .slice(0, 2)

                const isCurrentUser = member.id === members.find((m) => m.role === userRole)?.id
                const canModifyMember = canManageMembers && member.role !== "owner" && !isCurrentUser

                return (
                  <div key={member.id} className="flex items-center justify-between p-3 bg-slate-50 rounded-lg">
                    <div className="flex items-center space-x-3">
                      <Avatar className="w-10 h-10">
                        <AvatarImage src={member.profiles.avatar_url || ""} />
                        <AvatarFallback className="bg-blue-600 text-white">{initials}</AvatarFallback>
                      </Avatar>
                      <div>
                        <p className="font-medium text-slate-900">
                          {member.profiles.display_name}
                          {isCurrentUser && <span className="text-slate-500 ml-1">(You)</span>}
                        </p>
                        <p className="text-sm text-slate-600">{member.profiles.email}</p>
                      </div>
                    </div>

                    <div className="flex items-center space-x-2">
                      {canModifyMember ? (
                        <Select value={member.role} onValueChange={(value) => handleRoleChange(member.id, value)}>
                          <SelectTrigger className="w-24">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="member">Member</SelectItem>
                            <SelectItem value="admin">Admin</SelectItem>
                          </SelectContent>
                        </Select>
                      ) : (
                        <Badge className={getRoleBadgeColor(member.role)}>{member.role}</Badge>
                      )}

                      {canModifyMember && (
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => handleRemoveMember(member.id)}
                          className="text-red-600 hover:text-red-700 hover:bg-red-50"
                        >
                          <Trash2 className="w-4 h-4" />
                        </Button>
                      )}
                    </div>
                  </div>
                )
              })}
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
