"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Plus, Users, MessageSquare, Settings } from "lucide-react"
import { CreateProjectDialog } from "@/components/create-project-dialog"
import { useState } from "react"

export function QuickActions() {
  const [createProjectOpen, setCreateProjectOpen] = useState(false)

  return (
    <Card>
      <CardHeader className="pb-3">
        <CardTitle className="text-lg">Quick Actions</CardTitle>
      </CardHeader>
      <CardContent className="space-y-3">
        <Button
          className="w-full justify-start bg-blue-600 hover:bg-blue-700"
          onClick={() => setCreateProjectOpen(true)}
        >
          <Plus className="w-4 h-4 mr-2" />
          New Project
        </Button>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-1 gap-2">
          <Button variant="outline" className="justify-start bg-transparent" size="sm">
            <Users className="w-4 h-4 mr-2" />
            Invite Team
          </Button>
          <Button variant="outline" className="justify-start bg-transparent" size="sm">
            <MessageSquare className="w-4 h-4 mr-2" />
            View Messages
          </Button>
          <Button variant="outline" className="justify-start bg-transparent" size="sm">
            <Settings className="w-4 h-4 mr-2" />
            Settings
          </Button>
        </div>

        <CreateProjectDialog open={createProjectOpen} onOpenChange={setCreateProjectOpen} />
      </CardContent>
    </Card>
  )
}
