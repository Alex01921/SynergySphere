"use client"

import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { FolderOpen, CheckSquare, Users, MessageSquare, AlertTriangle } from "lucide-react"
import { isAfter, isToday, isTomorrow } from "date-fns"

interface Project {
  id: string
  name: string
  project_members: { role: string }[]
  tasks: { id: string; status: string; due_date: string | null }[]
  discussions: { id: string; updated_at: string }[]
}

interface DashboardStatsProps {
  projects: Project[]
  userId: string
}

export function DashboardStats({ projects, userId }: DashboardStatsProps) {
  // Calculate stats
  const totalProjects = projects.length
  const totalTasks = projects.reduce((sum, project) => sum + project.tasks.length, 0)
  const completedTasks = projects.reduce(
    (sum, project) => sum + project.tasks.filter((task) => task.status === "done").length,
    0,
  )
  const inProgressTasks = projects.reduce(
    (sum, project) => sum + project.tasks.filter((task) => task.status === "in_progress").length,
    0,
  )
  const totalDiscussions = projects.reduce((sum, project) => sum + project.discussions.length, 0)

  // Calculate overdue tasks
  const overdueTasks = projects.reduce((sum, project) => {
    return (
      sum +
      project.tasks.filter((task) => {
        if (!task.due_date || task.status === "done") return false
        return isAfter(new Date(), new Date(task.due_date))
      }).length
    )
  }, 0)

  // Calculate tasks due today/tomorrow
  const tasksDueToday = projects.reduce((sum, project) => {
    return (
      sum +
      project.tasks.filter((task) => {
        if (!task.due_date || task.status === "done") return false
        return isToday(new Date(task.due_date))
      }).length
    )
  }, 0)

  const tasksDueTomorrow = projects.reduce((sum, project) => {
    return (
      sum +
      project.tasks.filter((task) => {
        if (!task.due_date || task.status === "done") return false
        return isTomorrow(new Date(task.due_date))
      }).length
    )
  }, 0)

  const stats = [
    {
      title: "Active Projects",
      value: totalProjects,
      icon: FolderOpen,
      color: "text-blue-600",
      bgColor: "bg-blue-100",
    },
    {
      title: "Total Tasks",
      value: totalTasks,
      icon: CheckSquare,
      color: "text-green-600",
      bgColor: "bg-green-100",
      subtitle: `${completedTasks} completed`,
    },
    {
      title: "In Progress",
      value: inProgressTasks,
      icon: Users,
      color: "text-orange-600",
      bgColor: "bg-orange-100",
    },
    {
      title: "Discussions",
      value: totalDiscussions,
      icon: MessageSquare,
      color: "text-purple-600",
      bgColor: "bg-purple-100",
    },
  ]

  return (
    <div className="space-y-4 mb-6 sm:mb-8">
      {/* Main Stats Grid */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        {stats.map((stat) => (
          <Card key={stat.title} className="bg-white">
            <CardContent className="p-4 sm:p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-slate-600 mb-1">{stat.title}</p>
                  <p className="text-2xl sm:text-3xl font-bold text-slate-900">{stat.value}</p>
                  {stat.subtitle && <p className="text-xs text-slate-500 mt-1">{stat.subtitle}</p>}
                </div>
                <div
                  className={`w-10 h-10 sm:w-12 sm:h-12 ${stat.bgColor} rounded-lg flex items-center justify-center`}
                >
                  <stat.icon className={`w-5 h-5 sm:w-6 sm:h-6 ${stat.color}`} />
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Alerts Row */}
      {(overdueTasks > 0 || tasksDueToday > 0 || tasksDueTomorrow > 0) && (
        <div className="flex flex-wrap gap-2">
          {overdueTasks > 0 && (
            <Badge variant="destructive" className="flex items-center space-x-1">
              <AlertTriangle className="w-3 h-3" />
              <span>
                {overdueTasks} overdue task{overdueTasks !== 1 ? "s" : ""}
              </span>
            </Badge>
          )}
          {tasksDueToday > 0 && (
            <Badge variant="secondary" className="bg-orange-100 text-orange-800 flex items-center space-x-1">
              <CheckSquare className="w-3 h-3" />
              <span>{tasksDueToday} due today</span>
            </Badge>
          )}
          {tasksDueTomorrow > 0 && (
            <Badge variant="secondary" className="bg-blue-100 text-blue-800 flex items-center space-x-1">
              <CheckSquare className="w-3 h-3" />
              <span>{tasksDueTomorrow} due tomorrow</span>
            </Badge>
          )}
        </div>
      )}
    </div>
  )
}
