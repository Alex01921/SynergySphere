-- Create discussions table for project conversations
CREATE TABLE IF NOT EXISTS public.discussions (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id UUID NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE,
  title TEXT NOT NULL,
  created_by UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Create messages table for discussion messages
CREATE TABLE IF NOT EXISTS public.messages (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  discussion_id UUID NOT NULL REFERENCES public.discussions(id) ON DELETE CASCADE,
  content TEXT NOT NULL,
  author_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  parent_id UUID REFERENCES public.messages(id) ON DELETE CASCADE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS on discussions
ALTER TABLE public.discussions ENABLE ROW LEVEL SECURITY;

-- Enable RLS on messages
ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for discussions (users can see discussions in projects they're members of)
CREATE POLICY "discussions_select_project_member" ON public.discussions 
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM public.project_members 
      WHERE project_id = discussions.project_id AND user_id = auth.uid()
    )
  );

CREATE POLICY "discussions_insert_project_member" ON public.discussions 
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.project_members 
      WHERE project_id = discussions.project_id AND user_id = auth.uid()
    )
  );

CREATE POLICY "discussions_update_author" ON public.discussions 
  FOR UPDATE USING (auth.uid() = created_by);

CREATE POLICY "discussions_delete_author" ON public.discussions 
  FOR DELETE USING (auth.uid() = created_by);

-- Create RLS policies for messages
CREATE POLICY "messages_select_project_member" ON public.messages 
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM public.discussions d
      JOIN public.project_members pm ON pm.project_id = d.project_id
      WHERE d.id = messages.discussion_id AND pm.user_id = auth.uid()
    )
  );

CREATE POLICY "messages_insert_project_member" ON public.messages 
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.discussions d
      JOIN public.project_members pm ON pm.project_id = d.project_id
      WHERE d.id = messages.discussion_id AND pm.user_id = auth.uid()
    )
  );

CREATE POLICY "messages_update_author" ON public.messages 
  FOR UPDATE USING (auth.uid() = author_id);

CREATE POLICY "messages_delete_author" ON public.messages 
  FOR DELETE USING (auth.uid() = author_id);

-- Create triggers for updated_at
CREATE TRIGGER update_discussions_updated_at 
  BEFORE UPDATE ON public.discussions 
  FOR EACH ROW 
  EXECUTE FUNCTION update_updated_at_column();

CREATE TRIGGER update_messages_updated_at 
  BEFORE UPDATE ON public.messages 
  FOR EACH ROW 
  EXECUTE FUNCTION update_updated_at_column();

-- Create indexes for better performance
CREATE INDEX idx_discussions_project_id ON public.discussions(project_id);
CREATE INDEX idx_messages_discussion_id ON public.messages(discussion_id);
CREATE INDEX idx_messages_parent_id ON public.messages(parent_id);
