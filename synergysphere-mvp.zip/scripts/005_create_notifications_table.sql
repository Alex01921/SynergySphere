-- Create notifications table
CREATE TABLE IF NOT EXISTS public.notifications (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  type TEXT NOT NULL CHECK (type IN ('task_assigned', 'task_due', 'project_invitation', 'new_message', 'project_update', 'member_added')),
  title TEXT NOT NULL,
  message TEXT NOT NULL,
  data JSONB DEFAULT '{}',
  read_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Enable RLS on notifications
ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for notifications (users can only see their own notifications)
CREATE POLICY "notifications_select_own" ON public.notifications 
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "notifications_update_own" ON public.notifications 
  FOR UPDATE USING (auth.uid() = user_id);

CREATE POLICY "notifications_delete_own" ON public.notifications 
  FOR DELETE USING (auth.uid() = user_id);

-- Create indexes for better performance
CREATE INDEX idx_notifications_user_id ON public.notifications(user_id);
CREATE INDEX idx_notifications_created_at ON public.notifications(created_at DESC);
CREATE INDEX idx_notifications_read_at ON public.notifications(read_at);

-- Function to create notifications
CREATE OR REPLACE FUNCTION create_notification(
  p_user_id UUID,
  p_type TEXT,
  p_title TEXT,
  p_message TEXT,
  p_data JSONB DEFAULT '{}'
)
RETURNS UUID AS $$
DECLARE
  notification_id UUID;
BEGIN
  INSERT INTO public.notifications (user_id, type, title, message, data)
  VALUES (p_user_id, p_type, p_title, p_message, p_data)
  RETURNING id INTO notification_id;
  
  RETURN notification_id;
END;
$$ LANGUAGE plpgsql SECURITY DEFINER;

-- Function to notify project members about new tasks
CREATE OR REPLACE FUNCTION notify_task_assigned()
RETURNS TRIGGER AS $$
BEGIN
  -- Notify assignee if task is assigned to someone
  IF NEW.assignee_id IS NOT NULL THEN
    PERFORM create_notification(
      NEW.assignee_id,
      'task_assigned',
      'New task assigned',
      'You have been assigned to task: ' || NEW.title,
      jsonb_build_object(
        'task_id', NEW.id,
        'project_id', NEW.project_id,
        'task_title', NEW.title
      )
    );
  END IF;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Function to notify about new messages in discussions
CREATE OR REPLACE FUNCTION notify_new_message()
RETURNS TRIGGER AS $$
DECLARE
  discussion_record RECORD;
  member_record RECORD;
BEGIN
  -- Get discussion and project info
  SELECT d.*, p.id as project_id, p.name as project_name
  INTO discussion_record
  FROM discussions d
  JOIN projects p ON p.id = d.project_id
  WHERE d.id = NEW.discussion_id;
  
  -- Notify all project members except the message author
  FOR member_record IN
    SELECT pm.user_id
    FROM project_members pm
    WHERE pm.project_id = discussion_record.project_id
    AND pm.user_id != NEW.author_id
  LOOP
    PERFORM create_notification(
      member_record.user_id,
      'new_message',
      'New message in ' || discussion_record.title,
      'New message in discussion: ' || discussion_record.title,
      jsonb_build_object(
        'discussion_id', NEW.discussion_id,
        'project_id', discussion_record.project_id,
        'discussion_title', discussion_record.title
      )
    );
  END LOOP;
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Function to notify about new project members
CREATE OR REPLACE FUNCTION notify_member_added()
RETURNS TRIGGER AS $$
DECLARE
  project_record RECORD;
BEGIN
  -- Get project info
  SELECT * INTO project_record FROM projects WHERE id = NEW.project_id;
  
  -- Notify the new member
  PERFORM create_notification(
    NEW.user_id,
    'member_added',
    'Added to project',
    'You have been added to project: ' || project_record.name,
    jsonb_build_object(
      'project_id', NEW.project_id,
      'project_name', project_record.name,
      'role', NEW.role
    )
  );
  
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create triggers
CREATE TRIGGER trigger_notify_task_assigned
  AFTER INSERT ON public.tasks
  FOR EACH ROW
  EXECUTE FUNCTION notify_task_assigned();

CREATE TRIGGER trigger_notify_new_message
  AFTER INSERT ON public.messages
  FOR EACH ROW
  EXECUTE FUNCTION notify_new_message();

CREATE TRIGGER trigger_notify_member_added
  AFTER INSERT ON public.project_members
  FOR EACH ROW
  EXECUTE FUNCTION notify_member_added();
