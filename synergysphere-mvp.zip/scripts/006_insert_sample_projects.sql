-- Insert sample projects with realistic data
-- Note: This assumes you have at least one user in the system

-- Get the first user ID to use as project owner
DO $$
DECLARE
    sample_user_id UUID;
    project1_id UUID := gen_random_uuid();
    project2_id UUID := gen_random_uuid();
    project3_id UUID := gen_random_uuid();
    project4_id UUID := gen_random_uuid();
BEGIN
    -- Get a user ID (assumes at least one user exists)
    SELECT id INTO sample_user_id FROM auth.users LIMIT 1;
    
    IF sample_user_id IS NULL THEN
        RAISE EXCEPTION 'No users found. Please create a user account first.';
    END IF;

    -- Insert sample projects
    INSERT INTO projects (id, name, description, status, created_by, created_at, updated_at) VALUES
    (project1_id, 'Website Redesign', 'Complete overhaul of company website with modern design and improved user experience', 'active', sample_user_id, NOW() - INTERVAL '15 days', NOW() - INTERVAL '2 days'),
    (project2_id, 'Mobile App Development', 'Native iOS and Android app for customer engagement and service delivery', 'active', sample_user_id, NOW() - INTERVAL '30 days', NOW() - INTERVAL '1 day'),
    (project3_id, 'Marketing Campaign Q1', 'Comprehensive marketing strategy and campaign execution for Q1 product launch', 'completed', sample_user_id, NOW() - INTERVAL '60 days', NOW() - INTERVAL '10 days'),
    (project4_id, 'Database Migration', 'Migrate legacy database to modern cloud infrastructure with improved performance', 'planning', sample_user_id, NOW() - INTERVAL '5 days', NOW());

    -- Add project members (owner role)
    INSERT INTO project_members (project_id, user_id, role, joined_at) VALUES
    (project1_id, sample_user_id, 'owner', NOW() - INTERVAL '15 days'),
    (project2_id, sample_user_id, 'owner', NOW() - INTERVAL '30 days'),
    (project3_id, sample_user_id, 'owner', NOW() - INTERVAL '60 days'),
    (project4_id, sample_user_id, 'owner', NOW() - INTERVAL '5 days');

    -- Insert sample tasks for Website Redesign project
    INSERT INTO tasks (project_id, title, description, status, priority, assignee_id, due_date, created_by, created_at, updated_at) VALUES
    (project1_id, 'Design Homepage Mockup', 'Create wireframes and high-fidelity mockups for the new homepage design', 'completed', 'high', sample_user_id, NOW() - INTERVAL '10 days', sample_user_id, NOW() - INTERVAL '15 days', NOW() - INTERVAL '12 days'),
    (project1_id, 'Implement Responsive Navigation', 'Build mobile-first navigation component with accessibility features', 'in_progress', 'high', sample_user_id, NOW() + INTERVAL '3 days', sample_user_id, NOW() - INTERVAL '8 days', NOW() - INTERVAL '1 day'),
    (project1_id, 'Content Migration', 'Migrate existing content to new CMS structure', 'todo', 'medium', sample_user_id, NOW() + INTERVAL '7 days', sample_user_id, NOW() - INTERVAL '5 days', NOW() - INTERVAL '5 days'),
    (project1_id, 'SEO Optimization', 'Implement SEO best practices and meta tags', 'todo', 'low', sample_user_id, NOW() + INTERVAL '14 days', sample_user_id, NOW() - INTERVAL '3 days', NOW() - INTERVAL '3 days');

    -- Insert sample tasks for Mobile App Development project
    INSERT INTO tasks (project_id, title, description, status, priority, assignee_id, due_date, created_by, created_at, updated_at) VALUES
    (project2_id, 'User Authentication Flow', 'Implement secure login and registration system', 'completed', 'high', sample_user_id, NOW() - INTERVAL '20 days', sample_user_id, NOW() - INTERVAL '30 days', NOW() - INTERVAL '18 days'),
    (project2_id, 'Push Notifications Setup', 'Configure Firebase for iOS and Android push notifications', 'in_progress', 'high', sample_user_id, NOW() + INTERVAL '5 days', sample_user_id, NOW() - INTERVAL '10 days', NOW()),
    (project2_id, 'App Store Submission', 'Prepare app for App Store and Google Play submission', 'todo', 'medium', sample_user_id, NOW() + INTERVAL '21 days', sample_user_id, NOW() - INTERVAL '7 days', NOW() - INTERVAL '7 days');

    -- Insert sample tasks for Marketing Campaign (completed project)
    INSERT INTO tasks (project_id, title, description, status, priority, assignee_id, due_date, created_by, created_at, updated_at) VALUES
    (project3_id, 'Market Research Analysis', 'Conduct comprehensive market research and competitor analysis', 'completed', 'high', sample_user_id, NOW() - INTERVAL '50 days', sample_user_id, NOW() - INTERVAL '60 days', NOW() - INTERVAL '45 days'),
    (project3_id, 'Campaign Creative Assets', 'Design and produce all marketing materials and assets', 'completed', 'high', sample_user_id, NOW() - INTERVAL '35 days', sample_user_id, NOW() - INTERVAL '55 days', NOW() - INTERVAL '30 days'),
    (project3_id, 'Launch Event Planning', 'Organize and execute product launch event', 'completed', 'medium', sample_user_id, NOW() - INTERVAL '15 days', sample_user_id, NOW() - INTERVAL '40 days', NOW() - INTERVAL '12 days');

    -- Insert sample discussions
    INSERT INTO discussions (project_id, title, created_by, created_at, updated_at) VALUES
    (project1_id, 'Color Scheme Feedback', sample_user_id, NOW() - INTERVAL '8 days', NOW() - INTERVAL '2 days'),
    (project1_id, 'Mobile Navigation UX', sample_user_id, NOW() - INTERVAL '5 days', NOW() - INTERVAL '1 day'),
    (project2_id, 'API Integration Strategy', sample_user_id, NOW() - INTERVAL '12 days', NOW() - INTERVAL '3 days'),
    (project4_id, 'Database Schema Review', sample_user_id, NOW() - INTERVAL '3 days', NOW() - INTERVAL '1 day');

    -- Insert sample messages for discussions
    INSERT INTO messages (discussion_id, content, author_id, created_at) VALUES
    ((SELECT id FROM discussions WHERE title = 'Color Scheme Feedback' LIMIT 1), 'I think we should go with a more modern blue palette. What does everyone think?', sample_user_id, NOW() - INTERVAL '8 days'),
    ((SELECT id FROM discussions WHERE title = 'Color Scheme Feedback' LIMIT 1), 'The blue looks great! Should we add some accent colors?', sample_user_id, NOW() - INTERVAL '2 days'),
    ((SELECT id FROM discussions WHERE title = 'Mobile Navigation UX' LIMIT 1), 'The hamburger menu might not be the best choice for our use case. Consider a tab bar?', sample_user_id, NOW() - INTERVAL '5 days'),
    ((SELECT id FROM discussions WHERE title = 'API Integration Strategy' LIMIT 1), 'We need to decide between REST and GraphQL for the mobile app backend.', sample_user_id, NOW() - INTERVAL '12 days'),
    ((SELECT id FROM discussions WHERE title = 'Database Schema Review' LIMIT 1), 'The migration plan looks solid. Should we schedule a maintenance window?', sample_user_id, NOW() - INTERVAL '3 days');

END $$;
