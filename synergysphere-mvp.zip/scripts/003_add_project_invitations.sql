-- Create project invitations table for pending invites
CREATE TABLE IF NOT EXISTS public.project_invitations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  project_id UUID NOT NULL REFERENCES public.projects(id) ON DELETE CASCADE,
  email TEXT NOT NULL,
  role TEXT NOT NULL DEFAULT 'member' CHECK (role IN ('admin', 'member')),
  invited_by UUID NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  token UUID NOT NULL DEFAULT gen_random_uuid(),
  expires_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT (NOW() + INTERVAL '7 days'),
  accepted_at TIMESTAMP WITH TIME ZONE,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  UNIQUE(project_id, email)
);

-- Enable RLS on project invitations
ALTER TABLE public.project_invitations ENABLE ROW LEVEL SECURITY;

-- Create RLS policies for project invitations
CREATE POLICY "invitations_select_project_member" ON public.project_invitations 
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM public.project_members 
      WHERE project_id = project_invitations.project_id AND user_id = auth.uid()
    )
  );

CREATE POLICY "invitations_insert_project_admin" ON public.project_invitations 
  FOR INSERT WITH CHECK (
    EXISTS (
      SELECT 1 FROM public.project_members 
      WHERE project_id = project_invitations.project_id 
      AND user_id = auth.uid() 
      AND role IN ('owner', 'admin')
    )
  );

CREATE POLICY "invitations_delete_project_admin" ON public.project_invitations 
  FOR DELETE USING (
    EXISTS (
      SELECT 1 FROM public.project_members 
      WHERE project_id = project_invitations.project_id 
      AND user_id = auth.uid() 
      AND role IN ('owner', 'admin')
    )
  );

-- Add index for faster lookups
CREATE INDEX idx_project_invitations_token ON public.project_invitations(token);
CREATE INDEX idx_project_invitations_email ON public.project_invitations(email);
